CREATE VIEW cuentasbancosproveedor AS
  SELECT
    `platform_froxa`.`cuentasbancosterceros`.`id`                         AS `id`,
    `platform_froxa`.`cuentasbancosterceros`.`__descripcion`              AS `__descripcion`,
    `platform_froxa`.`cuentasbancosterceros`.`__erp`                      AS `__erp`,
    `platform_froxa`.`cuentasbancosterceros`.`__ccc`                      AS `__ccc`,
    `platform_froxa`.`cuentasbancosterceros`.`__cccekon`                  AS `__cccekon`,
    `platform_froxa`.`cuentasbancosterceros`.`__ccca3`                    AS `__ccca3`,
    `platform_froxa`.`cuentasbancosterceros`.`__banco__id`                AS `__banco__id`,
    `platform_froxa`.`cuentasbancosterceros`.`__banco____codigo`          AS `__banco____codigo`,
    `platform_froxa`.`cuentasbancosterceros`.`__proveedor__id`            AS `__proveedor__id`,
    `platform_froxa`.`cuentasbancosterceros`.`__proveedor____description` AS `__proveedor____description`,
    `platform_froxa`.`cuentasbancosterceros`.`__tercero`                  AS `__tercero`
  FROM `platform_froxa`.`cuentasbancosterceros`
  WHERE (`platform_froxa`.`cuentasbancosterceros`.`__tercero` = 'P');
