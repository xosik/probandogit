CREATE VIEW cuentascontablesproveedor AS
  SELECT
    `platform_froxa`.`cuentascontables`.`id`             AS `id`,
    `platform_froxa`.`cuentascontables`.`__terceros__id` AS `__terceros__id`,
    `platform_froxa`.`cuentascontables`.`__codigo`       AS `__codigo`,
    `platform_froxa`.`cuentascontables`.`__plan`         AS `__plan`,
    `platform_froxa`.`cuentascontables`.`__descripcion`  AS `__descripcion`
  FROM `platform_froxa`.`cuentascontables`
  WHERE (substr(`platform_froxa`.`cuentascontables`.`id`, 1, 3) = '400');
