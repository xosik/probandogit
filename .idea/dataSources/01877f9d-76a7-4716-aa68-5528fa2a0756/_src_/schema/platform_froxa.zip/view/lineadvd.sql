CREATE VIEW lineadvd AS
  SELECT
    `l`.`id`                                                               AS `id`,
    `l`.`__state`                                                          AS `__state`,
    `l`.`__articulo__id`                                                   AS `__articulo__id`,
    `l`.`__lote__id`                                                       AS `__lote__id`,
    `l`.`__centroimputacion__id`                                           AS `__centroimputacion__id`,
    `l`.`__almacen__id`                                                    AS `__almacen__id`,
    `l`.`__pedido__id`                                                     AS `__pedido__id`,
    `l`.`__dvd__id`                                                        AS `__dvd__id`,
    `l`.`__dua__id`                                                        AS `__dua__id`,
    `l`.`created_at`                                                       AS `created_at`,
    `l`.`updated_at`                                                       AS `updated_at`,
    `l`.`__pedido____divisa`                                               AS `__pedido____divisa`,
    `l`.`__articulo____iva`                                                AS `__articulo____iva`,
    `l`.`__articulo____arancel`                                            AS `__articulo____arancel`,
    `l`.`__articulo____erp`                                                AS `__articulo____erp`,
    `l`.`__articulo____descripcion`                                        AS `__articulo____descripcion`,
    `l`.`__articulo____pesobruto`                                          AS `__articulo____pesobruto`,
    `l`.`__articulo____factorcajas`                                        AS `__articulo____factorcajas`,
    `l`.`__lote____numerolote`                                             AS `__lote____numerolote`,
    `l`.`__lote____fechaproduccion`                                        AS `__lote____fechaproduccion`,
    `l`.`__lote____fechaconsumopreferente`                                 AS `__lote____fechaconsumopreferente`,
    `l`.`__arancel`                                                        AS `__arancel`,
    `l`.`__numerolote`                                                     AS `__numerolote`,
    `l`.`__valororigen`                                                    AS `__valororigen`,
    `l`.`__descripcion`                                                    AS `__descripcion`,
    `l`.`__valorpeso`                                                      AS `__valorpeso`,
    `l`.`__unidades`                                                       AS `__unidades`,
    `l`.`__peso`                                                           AS `__peso`,
    `l`.`__cajas`                                                          AS `__cajas`,
    round((`l`.`__valororigen` * (SELECT `d`.`__cambio`
                                  FROM `platform_froxa`.`dvd` `d`
                                  WHERE (`d`.`id` = `l`.`__dvd__id`))), 4) AS `__valor`
  FROM `platform_froxa`.`lineaimportacion` `l`
  WHERE (`l`.`__dvd__id` IS NOT NULL);
