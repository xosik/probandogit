CREATE VIEW lineadvd AS SELECT l.*, ROUND((__valororigen * (SELECT __cambio from dvd as d where d.id = l.__dvd__id )), 4) as __valor
from lineaimportacion as l where __dvd__id is not null;
