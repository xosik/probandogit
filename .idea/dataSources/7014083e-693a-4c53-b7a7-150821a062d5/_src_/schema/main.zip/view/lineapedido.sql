CREATE VIEW lineapedido AS SELECT * from lineaimportacion where __pedido__id is not null;
