CREATE VIEW cuentascontablescompra AS SELECT * from cuentascontables where substr(id, 1, 3) = '600';
