CREATE VIEW cuentascontablesventa AS SELECT * from cuentascontables where substr(id, 1, 3) = '700';
