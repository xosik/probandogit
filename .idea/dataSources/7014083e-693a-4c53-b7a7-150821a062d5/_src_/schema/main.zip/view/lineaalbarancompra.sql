CREATE VIEW lineaalbarancompra AS SELECT l.*, ROUND(__valorpeso * __unidades, 4) AS __valor  FROM lineacompra AS l WHERE __albarancompra__id IS NOT NULL;
