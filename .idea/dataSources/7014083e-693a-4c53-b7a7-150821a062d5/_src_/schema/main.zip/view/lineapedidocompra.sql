CREATE VIEW lineapedidocompra AS SELECT l.*,
(SELECT __ciclo || '/' || __referencia from pedidocompra as p where p.id = l.__pedidocompra__id ) as __pedido

 FROM lineacompra as l WHERE __pedidocompra__id IS NOT NULL;
