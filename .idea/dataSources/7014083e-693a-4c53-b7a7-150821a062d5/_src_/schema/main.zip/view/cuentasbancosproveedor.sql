CREATE VIEW cuentasbancosproveedor AS SELECT * from cuentasbancosterceros where __tercero = 'P';
