CREATE VIEW lineafacturacompra AS SELECT l.*, ROUND(__valorpeso * __unidades, 4) AS __valor  FROM lineacompra AS l WHERE __factura__id IS NOT NULL;
